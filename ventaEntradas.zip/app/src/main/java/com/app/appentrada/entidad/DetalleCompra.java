package com.app.appentrada.entidad;

public class DetalleCompra {


}
