package com.app.appentrada.dao;

public class MySqlPedido {


}
